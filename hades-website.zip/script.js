function summon() {
    alert("Gerbang dunia bawah telah terbuka... 🔥");
}
