# Hades Website Theme

Template website bertema Hades (dark myth aesthetic).

## Fitur
- Dark purple underworld theme
- Responsive layout
- Modern UI
- Siap upload ke GitHub

## Cara Menjalankan
1. Extract file zip
2. Buka `index.html` di browser

---
Project siap untuk commit 🚀
